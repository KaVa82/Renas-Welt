
import React from 'react';

interface SoundToggleProps {
    isSoundOn: boolean;
    onToggle: () => void;
}

export const SoundToggle: React.FC<SoundToggleProps> = ({ isSoundOn, onToggle }) => {
    return (
        <div className="fixed top-5 right-5 z-50 group">
            <button
                onClick={onToggle}
                className="w-12 h-12 bg-black/50 border border-[#d4a657]/50 rounded-full flex items-center justify-center text-2xl text-[#f0e6d2] backdrop-blur-sm transition-colors duration-300 hover:bg-[#d4a657]/30"
                aria-label={isSoundOn ? "Mute sound" : "Unmute sound"}
            >
                {isSoundOn ? (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                    </svg>
                ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                         <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 14l2-2m0 0l2-2m-2 2L17 8m2 2l2 2" />
                    </svg>
                )}
            </button>
            <div className="absolute top-1/2 -translate-y-1/2 right-full mr-3 px-3 py-1 bg-black/50 text-[#d4a657] text-sm rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap">
                Sound {isSoundOn ? 'On' : 'Off'}
            </div>
        </div>
    );
};
