
import React from 'react';
import { SacredSite } from '../types';

interface SiteChapterProps {
    site: SacredSite;
}

export const SiteChapter: React.FC<SiteChapterProps> = ({ site }) => {
    const backgroundStyle = {
        backgroundImage: `linear-gradient(rgba(12, 11, 9, 0.5), rgba(12, 11, 9, 0.8)), url('${site.imageUrl}')`,
    };

    return (
        <section style={backgroundStyle} className="h-screen w-full flex items-center justify-start bg-cover bg-center p-6 md:p-12 lg:px-24">
            <div className="max-w-2xl bg-[#0c0b09]/70 p-6 md:p-10 border-l-4 border-[#d4a657] backdrop-blur-sm rounded-r-lg animate-[fadeIn_2s_ease-out]">
                <h2 className="text-4xl md:text-5xl font-normal mb-4 text-[#d4a657]">
                    {site.title}
                </h2>
                <h3 className="text-xl md:text-2xl italic mb-6">{site.subtitle}</h3>

                <p className="text-lg md:text-xl mb-6 leading-relaxed italic text-stone-200">
                    {site.description}
                </p>

                <div className="my-8 text-center">
                    <p className="text-2xl md:text-3xl text-[#d4a657] font-serif tracking-wider">{site.mantra.sanskrit}</p>
                    <p className="text-md italic text-stone-400">({site.mantra.translation})</p>
                </div>

                <p className="text-lg md:text-xl my-6 p-4 border-y border-[#d4a657]/30 italic">
                    {site.reflection}
                </p>

                <blockquote className="mt-8 pl-4 border-l-2 border-[#d4a657]/50">
                    <p className="text-md italic text-stone-300">
                        "{site.quote.text}"
                    </p>
                    <cite className="block text-right mt-2 not-italic text-[#d4a657]">
                        - {site.quote.author}
                    </cite>
                </blockquote>
            </div>
        </section>
    );
};
