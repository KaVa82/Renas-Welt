
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { SiteChapter } from './SiteChapter';
import { SACRED_SITES } from '../constants';

export const Journey: React.FC = () => {
    const [activeSiteIndex, setActiveSiteIndex] = useState(0);
    const observer = useRef<IntersectionObserver | null>(null);
    const siteRefs = useRef<(HTMLDivElement | null)[]>([]);

    const handleScrollTo = (index: number) => {
        siteRefs.current[index]?.scrollIntoView({ behavior: 'smooth' });
    };

    const intersectionCallback = useCallback((entries: IntersectionObserverEntry[]) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const index = parseInt(entry.target.getAttribute('data-index') || '0', 10);
                setActiveSiteIndex(index);
            }
        });
    }, []);

    useEffect(() => {
        observer.current = new IntersectionObserver(intersectionCallback, {
            root: null,
            rootMargin: '0px',
            threshold: 0.6,
        });

        siteRefs.current.forEach(ref => {
            if (ref) {
                observer.current?.observe(ref);
            }
        });

        return () => {
            siteRefs.current.forEach(ref => {
                if (ref) {
                    observer.current?.unobserve(ref);
                }
            });
        };
    }, [intersectionCallback]);


    return (
        <div className="scroll-snap-type-y-mandatory h-screen overflow-y-scroll overflow-x-hidden">
            {SACRED_SITES.map((site, index) => (
                <div 
                    key={site.id} 
                    // FIX: The ref callback was implicitly returning a value because it was a concise arrow function. Ref callbacks must return void or a cleanup function. The assignment is now in a block to ensure an undefined return.
                    ref={el => { siteRefs.current[index] = el; }}
                    data-index={index}
                    className="scroll-snap-align-start"
                >
                    <SiteChapter site={site} />
                </div>
            ))}
            <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-30 flex gap-4">
                {SACRED_SITES.map((site, index) => (
                    <button
                        key={site.id}
                        onClick={() => handleScrollTo(index)}
                        className={`w-3 h-3 rounded-full transition-all duration-300 cursor-pointer ${
                            activeSiteIndex === index ? 'bg-[#d4a657] scale-125' : 'bg-[#d4a657]/40 hover:bg-[#d4a657]/70'
                        }`}
                        aria-label={`Go to ${site.title}`}
                    />
                ))}
            </div>
        </div>
    );
};
