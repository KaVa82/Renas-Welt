
import React from 'react';

interface IntroScreenProps {
    onBegin: () => void;
}

export const IntroScreen: React.FC<IntroScreenProps> = ({ onBegin }) => {
    const backgroundStyle = {
        backgroundImage: `linear-gradient(rgba(12, 11, 9, 0.7), rgba(12, 11, 9, 0.9)), url('https://images.unsplash.com/photo-1588392382834-a891154bca4d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80')`,
    };

    return (
        <div style={backgroundStyle} className="h-screen w-full flex flex-col justify-center items-center text-center p-5 relative overflow-hidden bg-cover bg-center">
            <div className="max-w-4xl z-10 animate-[fadeIn_3s_ease-out_forwards] [animation-delay:0.5s] opacity-0">
                <h1 className="text-4xl sm:text-6xl md:text-7xl font-normal mb-6 text-shadow tracking-wide">
                    Indiens heilige Stätten
                </h1>
                <p className="text-xl sm:text-2xl md:text-3xl mb-10 italic max-w-2xl mx-auto">
                    Eine spirituelle Reise durch Mystik und Hingabe
                </p>
                <p className="text-lg tracking-[3px] uppercase text-[#d4a657] font-semibold mb-12">
                    Für Rena
                </p>
                <button
                    onClick={onBegin}
                    className="bg-transparent border border-[#d4a657] text-white py-3 px-9 text-lg tracking-wider transition-all duration-300 ease-in-out hover:bg-[#d4a657]/20 hover:-translate-y-1"
                >
                    Beginne die Reise
                </button>
            </div>
            <div className="absolute top-[15%] left-[5%] text-9xl text-[#d4a657]/10 z-0 animate-[float_15s_ease-in-out_infinite]">
                ॐ
            </div>
        </div>
    );
};
