
import { SacredSite } from './types';

export const SACRED_SITES: SacredSite[] = [
  {
    id: 'varanasi',
    title: 'Varanasi',
    subtitle: 'Die Stadt des Lichts',
    imageUrl: 'https://images.unsplash.com/photo-1566423669093-183e30d37f33?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Stell dir vor, du stehst an den Ghats des heiligen Ganges, Rena. Die ersten Sonnenstrahlen berühren das Wasser. Der Duft von Sandelholz mischt sich mit dem Rauch der ewigen Feuer, wo Leben und Tod verschmelzen. Spürst du die Energie dieses Ortes? Das ewige Fließen des Flusses, der die Zyklen von Leben und Tod in sich trägt und Befreiung verspricht.',
    mantra: {
      sanskrit: 'ॐ नमः शिवाय',
      translation: 'Om Namah Shivaya',
    },
    reflection: 'Wenn ich hier stehe, spüre ich, wie die Grenzen zwischen Zeit und Ewigkeit verschwimmen. Was löst dieser Ort in dir aus, Rena? Kannst du das Flüstern der Jahrhunderte hören?',
    quote: {
      text: 'Varanasi ist älter als die Geschichte, älter als die Tradition, älter sogar als die Legende - und sieht doppelt so alt aus wie alle zusammen.',
      author: 'Mark Twain',
    },
  },
  {
    id: 'golden-temple',
    title: 'Harmandir Sahib',
    subtitle: 'Der Goldene Tempel',
    imageUrl: 'https://images.unsplash.com/photo-1600628421060-939639517883?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Rena, schau nur, wie sich der Tempel im heiligen Wasser spiegelt, eine Fata Morgana aus Gold und Marmor. Dieser Ort atmet Gleichheit und Hingabe. Hier sind alle willkommen, unabhängig von ihrem Glauben. Die Gesänge des Guru Granth Sahib sind eine Melodie, die direkt ins Herz geht. Spürst du die friedvolle Stimmung, die diesen Ort umhüllt?',
    mantra: {
      sanskrit: 'एक ओंकार',
      translation: 'Ek Onkar - Es gibt nur einen Schöpfer',
    },
    reflection: 'Ich erinnere mich, wie ich den Prasad empfing – eine einfache Speise, mit solcher Liebe gegeben. Rena, was bedeutet für dich wahre Gastfreundschaft?',
    quote: {
      text: 'Ich sehe Gott in jedem Menschen. Ich sehe Gott in jedem Grashalm.',
      author: 'Guru Nanak',
    },
  },
   {
    id: 'meenakshi-temple',
    title: 'Meenakshi Tempel',
    subtitle: 'Stadt der Göttin',
    imageUrl: 'https://images.unsplash.com/photo-1570197789255-3e91e539a2e8?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Rena, betrittst du mit mir diesen Wald aus tausend Skulpturen? Jeder der bunten Tortürme erzählt eine Geschichte. Der Duft von Jasmin liegt schwer in der Luft, vereint mit dem Klang der Tempelglocken. Spürst du die Präsenz der Göttin Meenakshi? Ihre Energie durchdringt jeden Winkel dieser heiligen Architektur.',
    mantra: {
      sanskrit: 'ॐ श्री मीनाक्ष्यै नमः',
      translation: 'Om Shri Meenakshyai Namah',
    },
    reflection: 'Als ich durch die Hallen wanderte, hatte ich das Gefühl, in einem lebendigen Organismus zu sein. Rena, was bedeutet Schönheit für dich, wenn sie göttlich wird?',
    quote: {
      text: 'In Madurai, Stadt der Tempel und Teiche, wo Götter auf der Straße wohnen...',
      author: 'A.K. Ramanujan',
    },
  },
  {
    id: 'tirupati-balaji',
    title: 'Tirupati Balaji',
    subtitle: 'Herz des Glaubens',
    imageUrl: 'https://images.unsplash.com/photo-1617665213123-5222409b8214?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Rena, wir steigen hoch in die Tirumala-Berge, wo der Himmel die Erde berührt. Fühlst du diese elektrische Energie? Täglich kommen Tausende hierher, manche legen Hunderte von Kilometern zu Fuß zurück, um Lord Venkateswara ihre Ehrerbietung zu erweisen. Es ist ein Ort der absoluten Hingabe, ein Ozean aus Glauben, in dem man sich selbst verliert und neu findet.',
    mantra: {
      sanskrit: 'ॐ नमो वेङ्कटेशाय',
      translation: 'Om Namo Venkatesaya',
    },
    reflection: 'Hier, inmitten dieser unvorstellbaren Menge, spüre ich eine tiefe Einheit. Was bedeutet es für dich, Rena, Teil von etwas so viel Größerem als du selbst zu sein?',
    quote: {
      text: 'Der Glaube ist ein Vogel, der das Licht fühlt und singt, wenn die Dämmerung noch dunkel ist.',
      author: 'Rabindranath Tagore',
    },
  },
  {
    id: 'jagannath-temple',
    title: 'Jagannath Tempel',
    subtitle: 'Herr des Universums',
    imageUrl: 'https://images.unsplash.com/photo-1600588223197-27a9172f3a8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Rena, sieh die gigantischen Holzwagen, die einmal im Jahr von Hunderttausenden durch die Straßen Puris gezogen werden. Das ist das Rath Yatra, ein Fest für den Herrn des Universums. Die hölzernen Götter mit ihren großen Augen blicken über die Menge. Kannst du diese unaufhaltsame Kraft spüren? Eine Welle der Hingabe, die alles mit sich reißt.',
    mantra: {
      sanskrit: 'जय जगन्नाथ',
      translation: 'Jai Jagannath',
    },
    reflection: 'Die Götter verlassen ihren Tempel, um zu den Menschen zu kommen. Was sagt dir das über die Nähe des Göttlichen im Alltäglichen, Rena?',
    quote: {
      text: 'In dieser Welt gibt es keine größere Kraft als die Kraft der Liebe und des Glaubens.',
      author: 'Sarada Devi',
    },
  },
    {
    id: 'somnath-temple',
    title: 'Somnath Tempel',
    subtitle: 'Phönix aus der Asche',
    imageUrl: 'https://images.unsplash.com/photo-1616689582287-935824c1b255?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Rena, hier am Arabischen Meer steht ein Tempel, der siebzehn Mal zerstört und immer wieder aufgebaut wurde. Er ist ein Monument der Unzerstörbarkeit des Glaubens. Die Wellen schlagen gegen die Mauern, als wollten sie die Geschichten von Zerstörung und Erneuerung erzählen. Spürst du die Kraft dieses Ortes, der sich immer wieder erhebt?',
    mantra: {
      sanskrit: 'ॐ नमः शिवाय',
      translation: 'Om Namah Shivaya',
    },
    reflection: 'Dieser Tempel lehrt, dass wahrer Glaube nicht in Steinen lebt, sondern in den Herzen. Was gibt dir die Kraft, nach Rückschlägen wieder aufzustehen, Rena?',
    quote: {
      text: 'Stärke wächst nicht aus körperlicher Kraft, sondern aus einem unbezwingbaren Willen.',
      author: 'Mahatma Gandhi',
    },
  },
  {
    id: 'brihadeeswarar-temple',
    title: 'Brihadeeswarar Tempel',
    subtitle: 'Der große Tempel',
    imageUrl: 'https://images.unsplash.com/photo-1582646452298-8a8b13c44569?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Rena, wir stehen vor einem Triumph menschlicher Vorstellungskraft, über tausend Jahre alt. Der gewaltige Turm wirft keinen Schatten auf den Boden. Ein 80 Tonnen schwerer Stein krönt seine Spitze. Wie war das möglich? Dieser Tempel ist nicht nur ein Ort des Gebets, sondern ein gefrorenes Zeugnis der Verschmelzung von Kunst, Wissenschaft und Spiritualität.',
    mantra: {
      sanskrit: 'शिवोऽहम्',
      translation: 'Shivoham - Ich bin Shiva',
    },
    reflection: 'Die Erbauer strebten nach Perfektion als Form des Gebets. In welchen Momenten deines Lebens fühlst du den Drang, etwas mit vollkommener Hingabe zu erschaffen, Rena?',
    quote: {
      text: 'Die Architektur sollte von der Ewigkeit sprechen.',
      author: 'Christopher Wren',
    },
  },
    {
    id: 'dilwara-temples',
    title: 'Dilwara Jain Tempel',
    subtitle: 'Gebete aus Marmor',
    imageUrl: 'https://images.unsplash.com/photo-1628182245392-49a71068222d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Stell dir vor, Rena, du betrittst einen Raum, in dem der Marmor so fein gemeißelt ist, dass er wie Spitze wirkt. Das Licht scheint durch den Stein zu fließen. Jeder Zentimeter ist ein Kunstwerk, geschaffen in stiller Kontemplation. Dieser Ort lehrt Ahimsa – absolute Gewaltlosigkeit. Spürst du die friedvolle Stille, die von den Wänden ausgeht?',
    mantra: {
      sanskrit: 'अहिंसा परमो धर्मः',
      translation: 'Ahimsa Paramo Dharmaḥ - Gewaltlosigkeit ist die höchste Tugend',
    },
    reflection: 'Die Künstler arbeiteten nicht für Ruhm, sondern aus reiner Hingabe. Was inspiriert dich, Rena, wenn du etwas tust, ohne eine Gegenleistung zu erwarten?',
    quote: {
      text: 'Die Schönheit der Dinge liegt in der Seele dessen, der sie betrachtet.',
      author: 'David Hume',
    },
  },
  {
    id: 'vaishno-devi',
    title: 'Vaishno Devi',
    subtitle: 'Der Ruf der Göttin',
    imageUrl: 'https://images.unsplash.com/photo-1591348122449-b844annabeeb315a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Rena, diese Reise ist eine Prüfung des Glaubens. Ein 12 Kilometer langer, steiler Pfad führt uns zu einer heiligen Höhle in den Bergen. Man sagt, die Göttin selbst ruft ihre Anhänger. Der Gesang "Jai Mata Di!" hallt durch die Täler und gibt den Pilgern Kraft. Spürst du, wie der Weg selbst zur Belohnung wird, wie jeder Schritt ein Gebet ist?',
    mantra: {
      sanskrit: 'जय माता दी',
      translation: 'Jai Mata Di - Sieg der Mutter Göttin',
    },
    reflection: 'Wahrer Glaube zeigt sich oft in der Bereitschaft, Unbequemlichkeit auf sich zu nehmen. Wofür wärst du bereit, einen langen und beschwerlichen Weg zu gehen, Rena?',
    quote: {
      text: 'Der Weg zum Gipfel beginnt mit dem ersten Schritt nach oben.',
      author: 'Unbekannt',
    },
  },
    {
    id: 'virupaksha-temple',
    title: 'Virupaksha Tempel',
    subtitle: 'Portal in eine andere Zeit',
    imageUrl: 'https://images.unsplash.com/photo-1582512278749-3174f7aad660?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Wir wandern durch Hampi, eine versunkene Stadt, wo Geschichte und Mythos verschmelzen. Inmitten der Ruinen steht dieser Tempel, ununterbrochen in Betrieb seit dem 7. Jahrhundert. Affen springen über alte Säulen, und der Fluss schlängelt sich durch riesige Felsen. Es fühlt sich an wie ein Portal in eine vergangene Welt, Rena. Kannst du dir die Pracht des alten Reiches vorstellen?',
    mantra: {
      sanskrit: 'ॐ विरूपाक्षाय नमः',
      translation: 'Om Virupakshaya Namah',
    },
    reflection: 'Selbst wenn Imperien fallen, bleibt der Glaube bestehen. Was in deinem Leben, Rena, hat die Kraft, die Zeit zu überdauern?',
    quote: {
      text: 'Die Geschichte ist nicht vergangen, sie ist nicht einmal vorbei.',
      author: 'William Faulkner',
    },
  },
   {
    id: 'lotus-temple',
    title: 'Lotus Tempel',
    subtitle: 'Einheit aller Religionen',
    imageUrl: 'https://images.unsplash.com/photo-1588136399133-2a3ab9c28cb8?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Rena, sieh diese sich öffnende Lotusblüte aus reinem Marmor. Ein Symbol der Reinheit, offen für Menschen jeden Glaubens. Es gibt keine Rituale, keine Priester, nur Stille. Die neun Eingänge symbolisieren, dass es viele Wege zum Göttlichen gibt. Hier können wir einfach nur sein, atmen und uns in der Stille verbinden.',
    mantra: {
      sanskrit: 'يا بهاء الأبهى',
      translation: 'Yá Bahá’u’l-Abhá - Oh Du Herrlichkeit des Allherrlichen',
    },
    reflection: 'An einem Ort, wo alle Wege zu einem Ziel führen, was bedeutet spirituelle Einheit für dich, Rena?',
    quote: {
      text: 'Die Erde ist nur ein Land, und alle Menschen sind seine Bürger.',
      author: 'Bahá’u’lláh',
    },
  },
    {
    id: 'rishikesh-aarti',
    title: 'Ganga Aarti',
    subtitle: 'Zeremonie des Lichts',
    imageUrl: 'https://images.unsplash.com/photo-1605305262338-e6c3e9a4f9b8?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Bei Sonnenuntergang versammeln wir uns am Ufer des Ganges in Rishikesh, Rena. Priester schwenken riesige Feuerschalen im Takt der Gesänge. Feuer und Wasser verschmelzen in einem hypnotisierenden Ritual. Wir lassen kleine Lichtschiffchen mit unseren Wünschen auf dem Fluss treiben. Es ist ein Moment reiner Magie, eine Gänsehaut, die tief aus der Seele kommt.',
    mantra: {
      sanskrit: 'ॐ जय गंगे माता',
      translation: 'Om Jai Gange Mata',
    },
    reflection: 'Wenn du dein Licht auf das Wasser schickst, welchen Wunsch oder welches Gebet würdest du ihm anvertrauen, Rena?',
    quote: {
      text: 'Tausende von Kerzen kann man am Licht einer einzigen Kerze anzünden, ohne dass ihr Leben kürzer wird. Glück nimmt nicht ab, wenn es geteilt wird.',
      author: 'Buddha',
    },
  },
  {
    id: 'khajuraho-temples',
    title: 'Khajuraho',
    subtitle: 'Die Umarmung des Göttlichen',
    imageUrl: 'https://images.unsplash.com/photo-1580749138332-37f6e52033c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Rena, diese Tempel zelebrieren das Leben in all seinen Facetten. Die berühmten Skulpturen sind nicht vulgär, sondern feiern die Vereinigung von Körper und Geist, von Shiva und Shakti, als Weg zur Erleuchtung. Sie lehren, dass Spiritualität das Körperliche nicht ausschließt, sondern es als Teil der göttlichen Schöpfung umarmt.',
    mantra: {
      sanskrit: 'कामदेव गायत्री',
      translation: 'Kamdev Gayatri Mantra',
    },
    reflection: 'Dieser Ort zeigt, dass Sinnlichkeit und Spiritualität zwei Seiten derselben Medaille sein können. Wie bringst du diese beiden Aspekte in deinem Leben in Einklang, Rena?',
    quote: {
      text: 'Der Körper ist der Tempel der Seele.',
      author: 'B.K.S. Iyengar',
    },
  },
    {
    id: 'bodh-gaya',
    title: 'Bodh Gaya',
    subtitle: 'Ort der Erleuchtung',
    imageUrl: 'https://images.unsplash.com/photo-1595287510141-5f63a3d5483a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Hier, unter einem Nachfahren des ursprünglichen Bodhi-Baumes, erreichte Siddhartha Gautama die Erleuchtung. Rena, spürst du die tiefe Stille, die diesen Ort durchdringt? Pilger aus aller Welt meditieren hier, umrunden den Tempel in ehrfürchtiger Andacht. Es ist ein lebendiges Zentrum, wo Sucher zusammenkommen, um inneren Frieden zu finden.',
    mantra: {
      sanskrit: 'ॐ मणि पद्मे हूँ',
      translation: 'Om Mani Padme Hum',
    },
    reflection: 'Buddha fand die Erleuchtung, als er aufhörte zu suchen und einfach nur saß. Was bedeutet es für dich, Stille im Geist zu finden, Rena?',
    quote: {
      text: 'Frieden kommt von innen. Suche ihn nicht außerhalb.',
      author: 'Buddha',
    },
  },
   {
    id: 'ajanta-ellora',
    title: 'Ajanta & Ellora',
    subtitle: 'Gebete in Stein gemeißelt',
    imageUrl: 'https://images.unsplash.com/photo-1578616239920-1a1a72d42055?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Rena, diese Tempel wurden nicht gebaut, sondern aus massivem Fels herausgeschnitten. Stell dir die Hingabe vor, die es brauchte, um den Kailasa-Tempel aus einem einzigen Stein zu hauen. Die alten Fresken erzählen Geschichten mit lebendigen Farben. Dies sind keine Kunstwerke – es sind gefrorene Gesänge, die seit Jahrtausenden zum Himmel aufsteigen.',
    mantra: {
      sanskrit: 'ॐ बुद्धाय नमः',
      translation: 'Om Buddhaya Namah',
    },
    reflection: 'Generationen von Künstlern arbeiteten an diesem Werk. Was würdest du erschaffen, Rena, wenn du wüsstest, dass es dich überdauern wird?',
    quote: {
      text: 'Geduld ist das Begleitelement des Genies.',
      author: 'Benjamin Disraeli',
    },
  },
   {
    id: 'pushkar',
    title: 'Pushkar',
    subtitle: 'Die Stadt Brahmas',
    imageUrl: 'https://images.unsplash.com/photo-1600269285742-f30a9a3b2b1e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Der Legende nach ließ Gott Brahma eine Lotusblüte fallen, und hier entstand der heilige Pushkar-See. Die Stadt ist ein Labyrinth aus Tempeln und bunten Basaren. Pilger nehmen ein rituelles Bad im See, um sich zu reinigen. Bei Sonnenuntergang, wenn die Aarti-Zeremonie beginnt, spürt man die zeitlose Magie dieses Ortes, Rena.',
    mantra: {
      sanskrit: 'ॐ ब्रह्मणे नमः',
      translation: 'Om Brahmane Namah',
    },
    reflection: 'Der See soll die Seele reinigen. Was bedeutet Reinigung für dich, Rena? Ein Loslassen von Vergangenem, ein Neuanfang?',
    quote: {
      text: 'Das Wasser ist die treibende Kraft aller Natur.',
      author: 'Leonardo da Vinci',
    },
  },
    {
    id: 'konark-sun-temple',
    title: 'Konark Sonnen-Tempel',
    subtitle: 'Hymnus an die Sonne',
    imageUrl: 'https://images.unsplash.com/photo-1595183350983-0931d86c26b7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Rena, dieser Tempel ist ein gigantischer Streitwagen für den Sonnengott, aus Stein gemeißelt. Die 24 Räder sind Sonnenuhren, die die genaue Zeit anzeigen. Obwohl er heute eine Ruine ist, strahlt er eine majestätische Würde aus. Bei Sonnenaufgang, wenn das Licht die Fassaden in flüssiges Gold verwandelt, spürt man die ewige Kraft der Sonne.',
    mantra: {
      sanskrit: 'ॐ सूर्याय नमः',
      translation: 'Om Suryaya Namah',
    },
    reflection: 'Die Sonne geht jeden Tag auf, ungeachtet dessen, was am Tag zuvor geschah. Welche Lektion über Neubeginn und Beständigkeit können wir von ihr lernen, Rena?',
    quote: {
      text: 'Wende dein Gesicht der Sonne zu, dann fallen die Schatten hinter dich.',
      author: 'Walt Whitman',
    },
  },
   {
    id: 'gangotri',
    title: 'Gangotri',
    subtitle: 'Quelle des Ganges',
    imageUrl: 'https://images.unsplash.com/photo-1629813515082-8c56c59d338f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Hoch im Himalaya, Rena, stehen wir an dem Ort, wo die Göttin Ganga die Erde betritt. Das türkisfarbene Wasser stürzt eiskalt über Felsen. Die Luft ist dünn und rein. Dies ist ein Schwellenland zwischen Himmel und Erde, wo das Göttliche greifbar wird. Die Pilgerreise hierher erfordert Ausdauer, aber der Anblick belohnt jede Mühe.',
    mantra: {
      sanskrit: 'ॐ गंगे च यमुने चैव',
      translation: 'Om Gange Cha Yamune Chaiva',
    },
    reflection: 'Wir sind an der Quelle eines Flusses, der Millionen von Menschen Leben spendet. Was ist die Quelle deiner eigenen Kraft und Inspiration, Rena?',
    quote: {
      text: 'Die Berge rufen, und ich muss gehen.',
      author: 'John Muir',
    },
  },
  {
    id: 'ranakpur-temple',
    title: 'Ranakpur Jain Tempel',
    subtitle: 'Ein Wald aus Marmor',
    imageUrl: 'https://images.unsplash.com/photo-1615655416336-1d13543b593f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Rena, wir treten in ein Labyrinth aus Licht und Marmor. 1.444 Säulen, und keine gleicht der anderen. Je nach Tageszeit ändert der Stein seine Farbe von Beige zu Weiß zu zartem Rosa. Der Tempel wirkt wie ein steinerner Wald, in dem Schatten und Licht ein ewiges Spiel tanzen. Hier spürt man eine tiefe, fast greifbare Ruhe.',
    mantra: {
      sanskrit: 'नमो अरिहंताणं',
      translation: 'Namo Arihantanam',
    },
    reflection: 'In diesem Labyrinth aus Säulen kann man sich verlieren und gleichzeitig finden. An welchen Orten verlierst du dich, um wieder zu dir selbst zu finden, Rena?',
    quote: {
      text: 'In der Stille und Geduld liegt die Kraft.',
      author: 'Franz von Sales',
    },
  },
  {
    id: 'arunachala',
    title: 'Arunachala',
    subtitle: 'Der Berg des Feuers',
    imageUrl: 'https://images.unsplash.com/photo-1588392382834-a891154bca4d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80',
    description: 'Rena, schau auf diesen heiligen Berg - nicht aus Stein, sondern aus reiner Bewusstseinsenergie. Bei Vollmond wandern Tausende schweigend um ihn herum. Der Legende nach ist Shiva selbst hier als Berg manifestiert. Spürst du die magnetische Anziehung dieses Ortes? Die Stille, die lauter spricht als alle Worte?',
    mantra: {
      sanskrit: 'अरुणाचल शिवोऽहम्',
      translation: 'Arunachala Shivoham - Ich bin Shiva Arunachala',
    },
    reflection: 'Hier, Rena, verstehe ich, dass wir nicht zur Erleuchtung gehen - wir kehren vielmehr zu ihr zurück. Kannst du das Feuer in deinem eigenen Herzen spüren?',
    quote: {
      text: 'Arunachala ist das Herz der Welt. Es ist der spirituelle Magnet, der alle Suchenden anzieht.',
      author: 'Ramana Maharshi',
    },
  },
];
