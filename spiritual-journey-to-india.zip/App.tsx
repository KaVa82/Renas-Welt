
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { IntroScreen } from './components/IntroScreen';
import { Journey } from './components/Journey';
import { SoundToggle } from './components/SoundToggle';

const App: React.FC = () => {
    const [isJourneyStarted, setIsJourneyStarted] = useState(false);
    const [isSoundOn, setIsSoundOn] = useState(false);
    const audioRef = useRef<HTMLAudioElement>(null);

    const handleBeginJourney = useCallback(() => {
        setIsJourneyStarted(true);
        setIsSoundOn(true);
    }, []);

    useEffect(() => {
        const audioElement = audioRef.current;
        if (!audioElement) return;

        if (isSoundOn) {
            audioElement.play().catch(error => {
                console.log("Audio playback was prevented by the browser.", error);
                setIsSoundOn(false);
            });
            audioElement.volume = 0.3;
        } else {
            audioElement.pause();
        }
    }, [isSoundOn]);

    return (
        <>
            <SoundToggle isSoundOn={isSoundOn} onToggle={() => setIsSoundOn(prev => !prev)} />
            
            {isJourneyStarted ? (
                <Journey />
            ) : (
                <IntroScreen onBegin={handleBeginJourney} />
            )}

            <audio ref={audioRef} loop>
                <source src="https://cdn.pixabay.com/download/audio/2022/01/19/audio_1c0d6b3e5a.mp3?filename=meditation-bells-and-flute-123785.mp3" type="audio/mpeg" />
                Your browser does not support the audio element.
            </audio>
        </>
    );
};

export default App;
