
export interface SacredSite {
  id: string;
  title: string;
  subtitle: string;
  imageUrl: string;
  description: string;
  mantra: {
    sanskrit: string;
    translation: string;
  };
  reflection: string;
  quote: {
    text: string;
    author: string;
  };
}
